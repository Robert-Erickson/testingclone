<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Vermont’s Wildlife: Learn and Photograph</title>
    <meta name="author" content="Robert Erickson">
    <meta name="description" content="Vermont is home to a large number of animals both large and small. Find a place where you can watch and photograph wildlife in their natural settings. Here we will journey through photos and facts about some of our favorites.">
    <meta name="viewport" content="width=device-width, intial-scale=1.0">
    <link rel="stylesheet" href="css/custom.css?version=<?php print time(); ?>" type="text/css">
    <link rel="stylesheet" media="(max-width: 800px)" href="css/custom-tablet.css?version=<?php print time(); ?>" type="text/css">
    <link rel="stylesheet" media="(max-width: 600px)" href="css/custom-phone.css?version=<?php print time(); ?>" type="text/css">
</head>

<body class="index">
    <header>
        <h1>Vermont Wildlife</h1>
        <h2>Facts and photographs</h2>
    </header>
    <nav>
        <a href="index.php">Home</a>
        <a href="detail.php">Whitetail&nbsp;Deer</a>
        <a href="form.php">Favorite&nbsp;Animal</a>
    </nav>
    <main>
        <h1>Wildlife Everywhere</h1>
        <section class="wildlife-everywhere">
            <h2>Wildlife Everywhere</h2>
            <p>Vermont has thousands of speices of wildlife though Birds and Mammals are the most popular, we also have our fair share of Amphibians, Fish and Reptiles. You can see wildlife from the city streets of Burlington to the deep backwoods of the Northeast Kingdom. The habitat determines which animals will be there.</p>
            <p>It is this habitiat that is crucial to the survial of the different animal species. In the early 1900 vt was mostly open fields and very little widlife. Old photos from that time period show very little forested areas.</p>
            <p>When the sheep farming market collapesed it allowed the once cleared land to regrow into young forests providing habitat for rabgits and grouse. The nation was also moving towards a trend of taking care of wild places adn forming fish and wildlife departments to help manage the populations and habitat, both forest, fields and streams.</p>
            <p>In 1878 we imported 17 deer from New York state, In 1921 beavers were reintroduced to the state. Of course this lead to beaver dams causing conflict with us humans. Today Vermont has a healthy population of both deer and beavers as well turkeys.</p>
            <p>I used to have a beaver pond in my backyard where I would sit every chance I had to watch the beavers do their thing. In the winter I would lay down on the black ice waiting for the beavers to swim by, mostly i just got cold. While working as a guide doing canoe trip on the Lamoille River we encoutered lots of wildlife and not just beavers. Here is a list of the common animals we saw.
        </section>

        <section class="common-wildlife-table">
            <h2>Common Vt Wildlife</h2>
            <table>
                <caption>Wildlife I have seen</caption>

                <tr>
                    <th>Type</th>
                    <th>Name</th>
                    <th>Status</th>
                </tr>

                <tr>
                    <td>Mammal</td>
                    <td>Beaver</td>
                    <td>Vermont's beaver population is healthy, prospering, and growing.</td>
                </tr>
                <tr>
                    <td>Mammal</td>
                    <td>Deer</td>
                    <td>Vermont's deer continue to remain in good health</td>
                </tr>
                <tr>
                    <td>Bird</td>
                    <td>Goldfinch</td>
                    <td>Common throughout Vermont, especially in areas that provide prime habitat, such as pastures and meadows. However, a 4% decline each year in the US overall could be a result of habitat loss</td>
                </tr>
                <tr>
                    <td>Mammal</td>
                    <td>Moose</td>
                    <td>The Vermont moose population is relatively stable at around 3,000 animals. This is changing as more moose are dying off due to winter ticks.</td>
                </tr>
                <tr>
                    <td colspan="3">Source: <cite><a href="https://vtfishandwildlife.com/learn-more/vermont-critters" target="_blank">https://vtfishandwildlife.com/learn-more/vermont-critters</a></cite></td>
                </tr>
            </table>
        </section>

        <section class="beavers-pond">
            <h2>Wildlife at the beaver pond</h2>
            <figure class="rounded go-right">
                <img class="rounded" alt="Beavers" src="images/Beaver.jpg">
                <figcaption><cite><a href="https://vtfishandwildlife.com/node/579" target="_blank">Vt Fish and Wildlife</a></cite></figcaption>
            </figure>
            <ol>
                <li>Beaver</li>
                <li>Fox</li>
                <li>King Fisher</li>
                <li>Merganser</li>
                <li>Otter</li>
                <li>Source: <cite>Robert Erickson</cite></li>
            </ol>
        </section>

    </main>

    <footer>
        <p><a href="../index.php">Site map</a></p>
    </footer>
</body>
</html>