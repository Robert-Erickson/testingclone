<nav>
    <a  class="<?php
    if($pathParts['filename'] == 'index') {
        print 'activePage';
    }
    ?>" href="index.php">Home</a>

    <a  class="<?php
    if($pathParts['filename'] == 'array') {
        print 'activePage';
    }
    ?>" href="array.php">Contest</a>

    <a  class="<?php
    if($pathParts['filename'] == 'detail') {
        print 'activePage';
    }
    ?>" href="detail.php">Whitetail&nbsp;Deer</a>
    
    <a  class="<?php
    if($pathParts['filename'] == 'form') {
        print 'activePage';
    }
    ?>" href="form.php">Favorite&nbsp;Animal</a>
</nav>