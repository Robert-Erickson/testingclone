<?php
include 'top.php';
$joesPondWinners = array(
    array(2017, 'Emily Wiggett', 'North Danville, VT', '4/23/17', '4:32 pm'),
    array(2018, 'Michael S. Cody', 'Barre, VT', '5/4/18', '11:27 am'),
    array(2019, 'Robynn L. Albert', 'Essex Junction, VT', '4/25/19', '5:39 am'),
    array(2020, 'Angela Buttura<br>​Nancy Durand', 'Essex Junction, VT<br>Hardwick, VT', '4/15/20', '6:07 am'),
    array(2021, 'Galina Mesko', 'Newport, VT', '4/10/21', '4:57 pm')
);
?>
    <main>
        <h1>Joes Pond Ice Out Contest</h1>
        <section class="Photography">
            <h2></h2>
            <figure class="rounded">
            <img class="rounded" alt="Joes pond" src="images/joes-pond.png">
            <figcaption>Sunrise at Joe's Pond<cite><a href="https://www.joespondvermont.com/ice-out.html"  target="blank">Joe's Pond website</a></cite></figcaption>
        </figure>
           
        </section>

        <section class="Places">
            <h2>Hisory of the contest</h2>
            <p>As we all do when sitting around we often talk about the weather and that is what Jules Chatot and his freinds were doing one winter day back in the 80's. Someone said "When do you think the ice is going out?"</p>
            
            <p>Of course it was asked so often they started making bets! After a few years of having a fun time of it Jules and his buddies thought they should expand the game to a contest to help raise money for Joe's Pond Association. The first year they opened the contest a few hundred people bought tickets. Today you can buy your tickets online and it has grown to over twelve thousand tickets each year.</p>

            <p>The money goes towards the july 4th fireworks, water quality program and other programs. You can read more at their web site: <a href="https://www.joespondvermont.com/ice-out.html"  target="blank">https://www.joespondvermont.com/ice-out.html</a></p>
        </section>

        <section class="Population">
            <h2>Last <?php print count($joesPondWinners);?> winners</h2>
            <table>
                <tr>
                    <th>Year</th>
                    <th>Winner</th>
                    <th>Town</th>
                    <th>Date</th>
                    <th>Time</th>
                </tr>
<?php
foreach($joesPondWinners as $joesPondWinner){
    print '<tr>';
    print '<td>' . $joesPondWinner[0] . '</td>';
    print '<td>' . $joesPondWinner[1] . '</td>';
    print '<td>' . $joesPondWinner[2] . '</td>';
    print '<td>' . $joesPondWinner[3] . '</td>';
    print '<td>' . $joesPondWinner[4] . '</td>';
    print '</tr>' . PHP_EOL;
}
?>
    </table>
 
        </section>
    </main>
<?php
include 'footer.php';
?>