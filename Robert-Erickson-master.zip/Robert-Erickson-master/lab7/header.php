<header>
    <h1>Vermont Wildlife</h1>
    <h2>Facts and photographs</h2>
</header>