<?php
include 'top.php';
?>
    <main>
        <h1>Whitetail Deer</h1>
        <section class="Photography">
            <h2>Photography</h2>
            <figure class="rounded">
            <img class="rounded" alt="Bob Erickson circ- 1982" src="images/mother-fawn.png">
            <figcaption>Momma with her newborn.</figcaption>
        </figure>
           
        </section>

        <section class="Population">
            <h2>Population</h2>
            <p>One of the most popular wild animals in Vermont is the whitetail deer. Easily spotted on the edge of fields in the morning and evening hours. Many people enjoy watching wildlife and the whitetail deer is one of Vermont's favorite. Of course if the deer is eating your Hostas or vegetable garden they may not be your favorite.</p>
            
            <p>There are a lot of deer in VT today thanks to sportsman who got together to help create laws to preserve habitat and prevent the over harvesting of this wonderful creature. For example in 1920 the Vermont Fish & Wildlife Department purchased 1,000 acres creating the Sandbar Wildlife Refuge, the states first wildlife management area (WMA).</p>
        </section>

        <section class="Places">
            <h2>Places to look</h2>

            <p>Today there are 100 WMA in Vermont which totals over 130,000 acres of wildlife habitat. In addition the VT Fish and Wildlife department holds more 50 easments protecting another 9,800 plus acres. Not as well known are what is called Riparian Lands owning many miles and hundres of acres along rivers, streams, ponds and lakes that provide the public with access to the waters for wildlife based activities.</p>
 
        </section>
    </main>
<?php
include 'footer.php';
?>