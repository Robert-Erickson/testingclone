<?php
include 'top.php';
?>
    <main>
        <h1>Your Favorite</h1>
        <section class="form-info"> 
            <figure class="rounded">
                <img class="rounded" alt="red Fox" src="images/red-fox.png">
                <figcaption><cite>Photo by Robert Erickson</cite></figcaption>
            </figure>
            <h2>Critter</h2>
            <p>We are collecting information about everyone's favorite animals to help protect them.</p>
        </section>

        <section  class="form-it-self">
            <h2>Your information will help us with our efforts.</h2>
            
            <form action="#" id="frmFavAnimal" method="post">

                <fieldset class="listbox">
                    <legend>Favorite Critter</legend>
                    <p>
                        <select id="lstFavoriteCritter" name="lstFavoriteCritter" tabindex="120">
                            <option value="Bear">Bear</option>
                            <option value="Beaver">Beaver</option>
                            <option value="Bird of Prey">Bird of Prey</option>
                            <option value="Deer">Deer</option>
                            <option value="Mouse">Mouse</option>
                            <option value="Rabbit">Rabbit</option>
                            <option value="Song Bird">Song Bird</option>
                            <option value="Wolf">Wolf</option>
                        </select>
                    </p>
                </fieldset>

                <fieldset class="textarea">
                    <p>
                        <label for="txtAttraction">Tell us what attracts you to this critter?</label>
                        <textarea id="txtAttraction" name="txtAttraction" tabindex="200"></textarea>
                    </p>
                </fieldset>

                <fieldset class="contact">
                    <legend>What about you?</legend>
                    <p>
                        <label class="required" for="txtFirstName">First Name</label>
                        <input id="txtFirstName" maxlength="30" name="txtFirstName" onfocus="this.select()" tabindex="300" type="text" value="" required>
                    </p>

                    <p>
                        <label class="required" for="txtAnimalName">Your Animal Name</label>
                        <input id="txtAnimalName" maxlength="30" name="txtAnimalName" onfocus="this.select()" tabindex="310" type="text" value="" required>
                    </p>
                </fieldset>

                <fieldset class="radio">
                    <legend>Are you a wildlife enthusiast?</legend>
                    <p>
                        <input type="radio" id="radEnthusiastDefinitely" name="radEnthusiast" value="Definitely" tabindex="410" required>
                        <label class="radio-field" for="radEnthusiastDefinitely">Definitely</label>
                    </p>

                    <p>
                        <input type="radio" id="radEnthusiastInterested" name="radEnthusiast" value="Interested" tabindex="430" required>
                        <label class="radio-field" for="radEnthusiastInterested"> Interested</label>
                    </p>

                    <p>
                        <input type="radio" id="radEnthusiastNo" name="radEnthusiast" value="No" tabindex="440" required>
                        <label class="radio-field" for="radEnthusiastNo"> No</label>
                    </p>
                </fieldset>

                <fieldset class="checkbox">
                    <legend>What describes you? (choose at least one)</legend>
                    <p>
                        <input id="chkWatcher" name="chkWatcher" tabindex="510" type="checkbox" value="1">
                        <label for="chkWatcher">Watcher</label>
                    </p>

                    <p>
                        <input id="chkHunter" name="chkHunter" tabindex="520" type="checkbox" value="1">
                        <label for="chkHunter">Hunter</label>
                    </p>

                    <p>
                        <input id="chkGatherer" name="chkGatherer" tabindex="530" type="checkbox" value="1">
                        <label for="chkGatherer">Gatherer</label>
                    </p>

                    <p>
                        <input id="chkSomething" name="chkSomething" tabindex="540" type="checkbox" value="1">
                        <label for="chkSomething">Something else</label>
                    </p>
                </fieldset>

                <fieldset class="buttons">
                    <input id="btnSubmit" name="btnSubmit" tabindex="900" type="submit" value="Register">
                </fieldset>
            </form>
        </section>

        <section class="form-feedback">
            <h2>Thank you</h2>
            <?php
            print '<p>Post Array:</p><pre>';
            print_r($_POST);
            print '</pre>';
            ?>
        </section>
    </main>
<?php
include 'footer.php';
?>