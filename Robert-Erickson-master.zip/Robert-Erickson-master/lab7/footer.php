    <footer>
        <p><a href="../index.php">Site map</a></p>
    </footer>
</body>
</html>