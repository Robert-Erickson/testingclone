<?php
include 'top.php';
?>
    <main>
    <h1>SQL</h1>
    <h2>Create table</h2>
    <pre>
    CREATE TABLE tblCommonWildlife (
        pmkCommonWildlifeId INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
        fldType varchar(10),
        fldWildlifeName varchar(30),
        fldWildlifeStatus varchar(250)
    )
    </pre>

    <h2>Insert Data</h2>
    <pre>
    INSERT INTO tblCommonWildlife (fldType, fldWildlifeName, fldWildlifeStatus) VALUES 
    ('Mammal', 'Beaver', 'Vermont\'s beaver population is healthy, prospering, and growing.'),
    ('Mammal', 'Deer', 'Vermont\'s deer continue to remain in good health.'),
    ('Bird', 'Goldfinch', 'Common throughout Vermont, especially in areas that provide prime habitat, such as pastures and meadows. However, a 4% decline each year in the US overall could be a result of habitat loss'),
    ('Mammal', 'Moose', 'The Vermont moose population is relatively stable at around 3,000 animals. This is changing as more moose are dying off due to winter ticks.')
    </pre>

    <h2>Select records</h2>
    <pre>
    SELECT fldType, fldWildlifeName, fldWildlifeStatus FROM tblCommonWildlife
    </pre>

    <h2>Create table for form</h2>
    <pre>
    CREATE TABLE tblFavoriteWildlife (
        pmkFavoriteWildlifeId INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
        fldFavoriteCritter varchar(15),
        fldAttraction text,
        fldFirstName varchar(40),
        fldEmail varchar(50),
        fldAnimalName varchar(40),
        fldEnthusiast varchar(11),
        fldWatcher tinyint(1),
        fldHunter tinyint(1),
        fldGather tinyint(1),
        fldSomething tinyint(1)
    )
    </pre>

    <h2>Insert record</h2>
    <pre>
    INSERT INTO tblFavoriteWildlife 
        (fldFavoriteCritter, fldAttraction, fldFirstName, fldEmail, fldAnimalName, fldEnthusiast, fldWatcher, fldHunter, fldGather, fldSomething) 
    VALUES 
        ('Beaver', 'I find it interesting that the beaver alters the environment to suit it own needs, kinda like we humans do.', 'Bob', 'rerickso@uvm.edu', 'Eagle', 'Definitely', '1', '1', '1', '0')
    </pre>
</main>
<?php
include 'footer.php';
?>