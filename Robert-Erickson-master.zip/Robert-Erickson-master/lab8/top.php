<?php
$phpSelf = htmlspecialchars($_SERVER['PHP_SELF']);
$pathParts = pathinfo($phpSelf);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Vermont’s Wildlife: Learn and Photograph</title>
    <meta name="author" content="Robert Erickson">
    <meta name="description" content="Vermont is home to a large number of animals both large and small. Find a place where you can watch and photograph wildlife in their natural settings. Here we will journey through photos and facts about some of our favorites.">
    <meta name="viewport" content="width=device-width, intial-scale=1.0">
    <link rel="stylesheet" href="css/custom.css?version=<?php print time(); ?>" type="text/css">
    <link rel="stylesheet" media="(max-width: 800px)" href="css/custom-tablet.css?version=<?php print time(); ?>" type="text/css">
    <link rel="stylesheet" media="(max-width: 600px)" href="css/custom-phone.css?version=<?php print time(); ?>" type="text/css">
    <link rel="icon" href="images/fox.ico">
</head>

<?php
print '<body id="' . $pathParts['filename'] . '">';
print '<!-- #################    Body element  ################# -->';
include 'connect-DB.php';
include 'header.php';
include 'nav.php';
?>