<!-- Connecting -->
<?php
$databaseName = 'CS008_labs';
$dsn = 'mysql:host=webdb.uvm.edu;dbname=' . $databaseName;
$username = 'cs008_writer';
$password = 'KNFrvrd4jNlc';
$pdo = new PDO($dsn, $username, $password);
?>
<!-- Connection complete -->