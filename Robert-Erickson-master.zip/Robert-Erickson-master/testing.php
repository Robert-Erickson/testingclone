<!DOCTYPE HTML>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Demo page for me</title>
    <meta name="author" content="Robert Erickson">
    <meta name="description" content="not for public">
</head>

<body>
    <h1>Testing Page</h1>
    <p>It's a little chilly today</p>
</body>

</html>