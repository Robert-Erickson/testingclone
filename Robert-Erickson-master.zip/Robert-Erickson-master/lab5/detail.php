<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Vermont’s Wildlife: Learn and Photograph</title>
    <meta name="author" content="Robert Erickson">
    <meta name="description" content="Vermont is home to a large number of animals both large and small. Find a place where you can watch and photograph wildlife in their natural settings. Here we will journey through photos and facts about some of our favorites.">
    <link rel="stylesheet" href="css/custom.css?version=<?php print time(); ?>" type="text/css">
</head>

<body class="flexbox-layout">
    <header>
        <h1>Vermont Wildlife</h1>
        <h2>Facts and photographs</h2>
    </header>
    <nav>
        <a href="index.php">Home</a>
        <a href="detail.php">Whitetail&nbsp;Deer</a>
        <a href="form.php">Favorite&nbsp;Animal</a>
    </nav>
    <main>
        <h1>Whitetail Deer</h1>
        <section class="Photography">
            <h2>Photography</h2>
            <figure class="rounded">
            <img class="rounded" alt="Bob Erickson circ- 1982" src="images/mother-fawn.png">
            <figcaption>Momma with her newborn.</figcaption>
        </figure>
           
        </section>

        <section class="Population">
            <h2>Population</h2>
            <p>One of the most popular wild animals in Vermont is the whitetail deer. Easily spotted on the edge of fields in the morning and evening hours. Many people enjoy watching wildlife and the whitetail deer is one of Vermont's favorite. Of course if the deer is eating your Hostas or vegetable garden they may not be your favorite.</p>
            
            <p>There are a lot of deer in VT today thanks to sportsman who got together to help create laws to preserve habitat and prevent the over harvesting of this wonderful creature. For example in 1920 the Vermont Fish & Wildlife Department purchased 1,000 acres creating the Sandbar Wildlife Refuge, the states first wildlife management area (WMA).</p>
        </section>

        <section class="Places">
            <h2>Places to look</h2>

            <p>Today there are 100 WMA in Vermont which totals over 130,000 acres of wildlife habitat. In addition the VT Fish and Wildlife department holds more 50 easments protecting another 9,800 plus acres. Not as well known are what is called Riparian Lands owning many miles and hundres of acres along rivers, streams, ponds and lakes that provide the public with access to the waters for wildlife based activities.</p>
 
        </section>
    </main>

    <footer>
        <p><a href="../index.php">Site map</a></p>
    </footer>
</body>
</html>